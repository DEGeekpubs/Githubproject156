require 'test_helper'

class ChargeOrderJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
