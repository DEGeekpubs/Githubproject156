class Admin::BookController < ApplicationController
  def action1
  end

  def action2
  end
end
